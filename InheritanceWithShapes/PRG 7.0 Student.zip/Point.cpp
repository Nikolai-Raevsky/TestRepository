#include "Point.h"

Point::Point()
{
    x = 0;
    y = 0;
}

Point::Point(float x_, float y_)
{
    x = x_;
    y = y_;
}